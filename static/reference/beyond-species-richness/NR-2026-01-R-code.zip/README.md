# Beyond Species Richness — NaturaLogic NR–2026–01

Exploratory study (19 November 2026 pilot; release preparation 25 November 2026). Elçin Ekşi. The original archived R scripts 02–06 and 09 were recovered; 11 is the archived figure script. These files have been inspected, not rerun in this environment. Data snapshots, R/package versions and source-tree checksum from the original run are not archived here. The repository is a transparent methods archive, not a certified fully reproducible release.

## Run in RStudio
Open `accipitriformes-phylogeny-niche.Rproj`. Install `readxl`, `readr`, `dplyr`, `tidyr`, `ggplot2`, `ape`. `phytools` is optional for the tanglegram (not used in the article). Download `Avoniche3_BirdTree2012.csv` from https://doi.org/10.5061/dryad.1zcrjdg56 and save it in `data/raw/`. Script 02 downloads the original AVONET workbook, script 06 downloads the published Aves 1.3 Clements 2022 tree. If download fails, obtain the files at the original source and retain the exact filenames in the scripts. Run from the project root in order:

```r
source("scripts/02_avonet_veri_dogrulama.R")
source("scripts/03_avoniche_birdtree_dogrulama.R")
source("scripts/04_accipitriformes_ekolojik_ozet.R")
source("scripts/05_accipitriformes_kalite_duyarlilik.R")
source("scripts/06_hizli_agac_kurtarma.R")
Sys.setenv(RAPTOR_PERM="499")
source("scripts/09_iki_agac_ekolojik_farklilasma_30dk.R")
source("scripts/11_yayin_figürleri.R")
```

The initial dataset contains 251 taxa; the direct tree match yielded 218. Expected historical results (rounded, not new execution): 32 niches rho=0.329, p=0.002; 9 diet groups rho=0.338, p=0.002; 28 genera rho=0.041, p=0.846. The last analysis preserves genus sizes but does not preserve phylogenetic structure under permutations. The 9-category result is a sensitivity check, not independent validation. 23,653 species pairs are not independent observations. Exact rerun results can change with source versions and software; report discrepancies rather than forcing agreement. Code 09 can stop at the optional plotting stage after writing its main CSV; the plotted tanglegram is not part of the article.

## Data provenance
- AVONET: https://doi.org/10.1111/ele.13898 ; https://doi.org/10.6084/m9.figshare.16586228
- AVONICHE: https://doi.org/10.1111/geb.70197 ; https://doi.org/10.5061/dryad.1zcrjdg56
- Aves 1.3: https://doi.org/10.1073/pnas.2409658122 ; https://github.com/McTavishLab/AvesData
- Hellinger: https://doi.org/10.1007/s004420100716
- Mantel limitations: https://doi.org/10.1111/j.1558-5646.2010.00973.x

Third-party data are not redistributed; their original licenses apply. Archive preserves original scripts, including comments, and adds only this README and RStudio project metadata. No new statistical analysis was conducted. The original analysis scripts and accompanying project documentation are released under the MIT license included here. This license does not cover third-party data, source publications, external packages, or the article and figures.
