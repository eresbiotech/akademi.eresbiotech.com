# 06_hizli_agac_kurtarma.R
# Prerequisite for 09; uses only the ape package.
# Published phylogenetic synthesis: McTavish et al. (2025), Aves 1.3, Clements 2022.
# Some tips may be grafted/imputed; not a de novo DNA sequence analysis.

if (!requireNamespace("ape", quietly=TRUE)) {
  stop('"ape" eksik. Mac icin once install.packages("ape", type="binary") calistirin.')
}
project_csv <- "data/processed/accipitriformes_avonet_avoniche_joined.csv"
if (!file.exists(project_csv)) stop("04 verisi bulunamadi: ", project_csv)

for (d in c("data/raw", "data/processed", "outputs/tables"))
  dir.create(d, recursive=TRUE, showWarnings=FALSE)

url <- paste0(
  "https://raw.githubusercontent.com/McTavishLab/AvesData/main/",
  "Tree_versions/Aves_1.3/Clements2022/summary_dated_clements.nex"
)
nex <- "data/raw/McTavish2025_Aves1.3_Clements2022_summary_dated.nex"
if (!file.exists(nex) || file.info(nex)$size < 10000) {
  message("Yayimlanmis filogenetik agac indiriliyor...")
  options(timeout = max(180, getOption("timeout")))
  utils::download.file(url, nex, mode="wb", method="libcurl", quiet=FALSE)
}
if (!file.exists(nex) || file.info(nex)$size < 10000) stop("Agac dosyasi eksik: ", nex)

phy <- ape::read.nexus(nex)
if (inherits(phy, "multiPhylo")) {
  if (length(phy) != 1L) stop("NEXUS dosyasi birden fazla agac iceriyor; elle secim gerekiyor.")
  phy <- phy[[1]]
}
if (!inherits(phy, "phylo")) stop("Okunan dosya phylo agaci degil.")
if (is.null(phy$edge.length) || any(!is.finite(phy$edge.length)))
  stop("Filogenetik dal uzunluklari eksik ya da gecersiz.")

z <- utils::read.csv(project_csv, check.names=FALSE, stringsAsFactors=FALSE)
if (!"Species3" %in% names(z)) stop("04 CSV dosyasinda Species3 kolonu yok.")
canon <- function(x) tolower(trimws(gsub("[[:space:]]+", " ", gsub("_", " ", x))))
if (anyDuplicated(canon(phy$tip.label))) stop("Agac uclarinda yinelenen tur adlari var.")
idx <- match(canon(z$Species3), canon(phy$tip.label))
valid <- which(!is.na(idx))
message("Eslesen tur: ",length(valid)," / ",nrow(z))
if (length(valid) < 100) stop("100'den az tur eslesti. Takson adlari denetlenmeli.")

mapping <- data.frame(Species3=z$Species3[valid],
                      tree_tip=phy$tip.label[idx[valid]],
                      stringsAsFactors=FALSE)
if (anyDuplicated(mapping$tree_tip)) stop("Iki veri turu ayni agac ucuna denk geldi.")
phy2 <- ape::drop.tip(phy, setdiff(phy$tip.label, mapping$tree_tip))
mapping <- mapping[match(phy2$tip.label,mapping$tree_tip),,drop=FALSE]
if (anyNA(mapping$tree_tip) || !identical(mapping$tree_tip,phy2$tip.label))
  stop("Agac ve eslesme tablosu siralanamadi.")

utils::write.csv(mapping,"data/processed/06_phylo_matched_traits.csv",row.names=FALSE)
saveRDS(phy2,"data/processed/06_phylogeny.rds")
utils::write.csv(data.frame(Species3=z$Species3[is.na(idx)]),
                 "outputs/tables/06_eslesmeyen_turler.csv",row.names=FALSE)
cat("06 KURTARMA TAMAMLANDI: ",length(phy2$tip.label)," tur.\n",
    "Simdi source('scripts/09_iki_agac_ekolojik_farklilasma_30dk.R') calistirin.\n",sep="")
