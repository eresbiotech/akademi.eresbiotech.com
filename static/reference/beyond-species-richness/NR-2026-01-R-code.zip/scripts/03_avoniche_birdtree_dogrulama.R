# AVONICHE BirdTree edition (Sayol et al. 2026)
# Data DOI: https://doi.org/10.5061/dryad.1zcrjdg56
# Designed to match AVONET's AVONET3_BirdTree table.
# Dryad may return HTTP 403 for scripted downloads, so download the CSV
# from the dataset page in your browser and save it under data/raw/.

if (!file.exists('accipitriformes-phylogeny-niche.Rproj')) {
  stop('RStudio proje dosyasini acin ve projenin kokunde calistirin.')
}
if (!requireNamespace('readr', quietly = TRUE)) install.packages('readr')

dir.create('data/raw', recursive = TRUE, showWarnings = FALSE)
dir.create('data/processed', recursive = TRUE, showWarnings = FALSE)

f <- 'data/raw/Avoniche3_BirdTree2012.csv'
if (!file.exists(f)) {
  stop(paste0(
    'AVONICHE dosyasi bulunamadi. Safari/tarayicida\n',
    'https://datadryad.org/dataset/doi:10.5061/dryad.1zcrjdg56\n',
    'adresini acin, Avoniche3_BirdTree2012.csv dosyasini indirin,\n',
    'data/raw/ klasorune tam bu adla kaydedin ve tekrar calistirin.'
  ))
}
if (is.na(file.info(f)$size) || file.info(f)$size < 100000) {
  stop('CSV boyutu beklenenden kucuk: bir HTML/hata dosyasi olabilir.')
}

avoniche <- tryCatch(
  readr::read_csv(f, show_col_types = FALSE),
  error = function(e) stop('CSV okunamadi: ', conditionMessage(e))
)
message('AVONICHE satir: ', nrow(avoniche), ' | sutun: ', ncol(avoniche))
message('AVONICHE kolon isimleri:')
print(names(avoniche))

avonet_file <- 'data/processed/avonet_accipitriformes_birdtree.csv'
if (!file.exists(avonet_file)) {
  stop('AVONET ciktisi yok. Once source("scripts/02_avonet_veri_dogrulama.R") calistirin.')
}
avonet <- readr::read_csv(avonet_file, show_col_types = FALSE)

# Find the taxon name column without assuming an unverified CSV schema.
choices <- c('Species3', 'Species', 'species', 'ScientificName',
             'Scientific.name', 'scientific_name', 'Species_name', 'species_name')
name_col <- choices[choices %in% names(avoniche)]
if (length(name_col) != 1L) {
  message('AVONICHE tur adi sutunu otomatik anlasilamadi. Yukaridaki kolonlari paylasin.')
  stop('Tur adlarini tahmin ederek birlestirmiyorum; once kolon yapisini dogrulayalim.')
}
clean_name <- function(x) tolower(trimws(gsub('_', ' ', as.character(x))))
selected <- avoniche[
  clean_name(avoniche[[name_col]]) %in% clean_name(avonet$Species3),
  , drop = FALSE
]
readr::write_csv(selected, 'data/processed/avoniche_accipitriformes_birdtree.csv')
matched <- unique(clean_name(selected[[name_col]]))
missing <- avonet$Species3[!(clean_name(avonet$Species3) %in% matched)]
message('AVONET Accipitriformes: ', nrow(avonet))
message('AVONICHE eslesen satir: ', nrow(selected))
message('Eslesmeyen AVONET tur adlari (ilk 20):')
print(utils::head(missing, 20))
message('Kaydedildi: data/processed/avoniche_accipitriformes_birdtree.csv')
message('NOT: Eslesme bir ekolojik analiz veya filogenetik test degildir.')
