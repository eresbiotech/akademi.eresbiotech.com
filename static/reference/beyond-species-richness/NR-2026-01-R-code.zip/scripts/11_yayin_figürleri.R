# 11 — Publication-oriented scientific figure drafts (TR)
# Uses already processed data and analysis tables. Does not alter 09 statistics.
# Packages: ape and ggplot2 only. No phytools/ggtree installation.
# Source in project root: source('scripts/11_yayin_figürleri.R')

for (pkg in c('ape','ggplot2')) {
  if (!requireNamespace(pkg, quietly=TRUE)) stop('Eksik paket: ', pkg)
}
required <- c(
  'data/processed/accipitriformes_avonet_avoniche_joined.csv',
  'data/processed/06_phylogeny.rds',
  'data/processed/06_phylo_matched_traits.csv',
  'outputs/tables/09_iki_agac_istatistik.csv',
  'outputs/tables/09_cins_zenginligi_nis_farkliligi.csv',
  'outputs/tables/05_esik_duyarliligi.csv'
)
missing <- required[!file.exists(required)]
if (length(missing)) stop('Eksik girdi:\n', paste(missing,collapse='\n'))

out <- 'outputs/figures/publication_11'
dir.create(out, recursive=TRUE, showWarnings=FALSE)

read_local <- function(path) utils::read.csv(path, check.names=FALSE, stringsAsFactors=FALSE)
z_all <- read_local(required[1]); tree <- readRDS(required[2]); map <- read_local(required[3])
res09 <- read_local(required[4]); genus <- read_local(required[5]); sens <- read_local(required[6])
stopifnot(inherits(tree,'phylo'))
stopifnot(all(c('Species3','dominant_diet_code') %in% names(z_all)))
stopifnot(all(c('Species3','tree_tip') %in% names(map)))
stopifnot(all(c('measure','mantel_like_spearman','permutation_p') %in% names(res09)))
stopifnot(all(c('genus','species_richness','mean_hellinger_32') %in% names(genus)))
stopifnot(!anyDuplicated(z_all$Species3), !anyDuplicated(map$tree_tip))

# Match in exact phylogenetic tip order, as done in 09.
ix <- match(tree$tip.label, map$tree_tip)
if (anyNA(ix)) stop('Agaç uçları / 06 eşleştirme tablosu tutarsız.')
zix <- match(map$Species3[ix], z_all$Species3)
if (anyNA(zix)) stop('04 verisinde bulunmayan filogenetik eslesme var.')
z <- z_all[zix,,drop=FALSE]
species <- gsub('_', ' ', z$Species3, fixed=TRUE)
N <- length(species)
if (N != length(tree$tip.label) || anyDuplicated(species)) stop('Takson sayısı veya isimleri tutarsız.')
cat('Filogenetik eşleşmiş tür sayısı:', N, '\n')

col9 <- c('Pa','Pt','Ne','Se','Fr','In','Ap','Vt','Ca')
col32 <- c('PAG','PAS','PAD','PEL','PGR','NAE','NGL','SEL','SGR',
           'FAE','FGL','FGR','IAE','ISA','ISS','ISG','IVS','IGE','IGG',
           'APA','APL','APP','APG','APS','APD','VAE','VAS','VPE','VGE','VGG',
           'CAQ','CGR')
if (!all(c(col9,col32) %in% names(z))) stop('32 niş veya 9 besin sütunu eksik.')

label9 <- c(Pa='Sucul bitkiler',Pt='Karasal bitkiler',Ne='Nektar',
            Se='Tohum',Fr='Meyve',In='Omurgasızlar',
            Ap='Sucul av',Vt='Omurgalılar',Ca='Leş')
# A colourblind-conscious categorical set, fixed across all categorical figures.
colour9 <- c(Pa='#DBA34B',Pt='#8F7AA8',Ne='#A6AB3D',Se='#4D9679',
             Fr='#009F91',In='#A16C52',Ap='#0072B2',Vt='#7654A3',Ca='#6D6F73')

H <- function(data, cols, keys) {
  a <- as.matrix(data[,cols,drop=FALSE]); storage.mode(a) <- 'double'
  if (any(!is.finite(a)) || any(a < 0) || any(rowSums(a) <= 0)) stop('Geçersiz niş skoru.')
  a <- sqrt(a/rowSums(a))
  d <- as.matrix(stats::dist(a))/sqrt(2)
  dimnames(d) <- list(keys,keys)
  d
}
D32 <- H(z, col32, species); D9 <- H(z,col9,species)
P <- ape::cophenetic.phylo(tree)
P <- P[tree$tip.label,tree$tip.label,drop=FALSE]
if (any(!is.finite(P))) stop('Geçersiz filogenetik uzaklık.')
u <- upper.tri(P)
pairs <- data.frame(phylo=P[u], niche32=D32[u], diet9=D9[u])
if (N*(N-1)/2 != nrow(pairs)) stop('Tür çiftleri hatalı.')
cat('Tür çifti sayısı:',nrow(pairs),'\n')

pub_theme <- function(base=11) ggplot2::theme_classic(base_size=base) +
  ggplot2::theme(plot.title=ggplot2::element_blank(),
                 plot.subtitle=ggplot2::element_blank(),
                 axis.title=ggplot2::element_text(size=base),
                 axis.text=ggplot2::element_text(colour='#252525'),
                 legend.title=ggplot2::element_text(size=base-1),
                 legend.text=ggplot2::element_text(size=base-1))

save_pub <- function(p, name, width, height) {
  ggplot2::ggsave(file.path(out,paste0(name,'.pdf')),p,device='pdf',
                  width=width,height=height,units='in',useDingbats=FALSE,
                  bg='white')
  ggplot2::ggsave(file.path(out,paste0(name,'.png')),p,device='png',
                  width=width,height=height,units='in',dpi=320,bg='white')
  cat('Üretildi: ',name,' (PDF ve PNG)\n',sep='')
}

# FIGURE 1A / 1B — bivariate bin frequencies, no regression CI.
maxP <- max(pairs$phylo)
xBin <- maxP/42
if (!is.finite(xBin) || xBin<=0) stop('Filogenetik mesafede varyasyon yok.')
make_distance <- function(yvar, key, label) {
  dd <- data.frame(phylo=pairs$phylo, ecological=pairs[[yvar]])
  rr <- res09[res09$measure==key,,drop=FALSE]
  if (nrow(rr)!=1) stop('09 sonuç tablosunda ölçü bulunamadı: ',key)
  note <- sprintf('Spearman rho = %.3f; permutasyon p = %.3f',
                  rr$mantel_like_spearman[1],rr$permutation_p[1])
  p <- ggplot2::ggplot(dd, ggplot2::aes(x=phylo,y=ecological)) +
    ggplot2::geom_bin2d(binwidth=c(xBin,1/35)) +
    ggplot2::scale_fill_gradient(low='#EDF4F6',high='#22586C',trans='sqrt',name='Çift sayısı') +
    ggplot2::scale_x_continuous(limits=c(0,maxP),expand=c(0,0)) +
    ggplot2::scale_y_continuous(limits=c(0,1),expand=c(0,0)) +
    ggplot2::labs(x='Filogenetik patristik uzaklık (ağaç birimi)',y=label,
                  caption=paste0(note,' | ',nrow(dd),' bağımsız OLMAYAN tür çifti')) +
    pub_theme(10) +
    ggplot2::theme(plot.caption=ggplot2::element_text(size=8,hjust=0))
  p
}
save_pub(make_distance('niche32','32_nis_besin_avlanma','Ekolojik Hellinger uzaklığı (32 niş)'),
         'Fig1A_32_nis_uzaklik',6.9,4.6)
save_pub(make_distance('diet9','9_besin','Ekolojik Hellinger uzaklığı (9 besin)'),
         'Fig1B_9_besin_uzaklik',6.9,4.6)

# FIGURE 2 — full 218-tip topology, categorical tip annotation.
# Deliberately no labels for 218 individual tips; 9-category colour legend.
diet_code <- as.character(z$dominant_diet_code)
if (!all(diet_code %in% col9)) stop('Beklenmeyen baskın besin kodu var.')
make_tree <- function() {
  old <- par(no.readonly=TRUE); on.exit(par(old),add=TRUE)
  par(mar=c(1,1,1,1),fg='#262626',xpd=NA)
  ape::plot.phylo(tree,type='fan',show.tip.label=FALSE,use.edge.length=TRUE,
                 edge.color='#9BA5A5',edge.width=.5,no.margin=FALSE)
  ape::tiplabels(tip=seq_len(N),pch=21,bg=unname(colour9[diet_code]),
                 col='#FFFFFF',cex=.55,frame='none')
  legend('topleft',legend=unname(label9[col9]),pch=21,pt.bg=unname(colour9[col9]),
         col='#FFFFFF',bty='n',pt.cex=1,cex=.75,title='Baskın besin grubu')
}
grDevices::pdf(file.path(out,'Fig2_filogenetik_uc_renkleri.pdf'),
               width=11,height=10.5,useDingbats=FALSE)
tryCatch(make_tree(),finally=grDevices::dev.off())
grDevices::png(file.path(out,'Fig2_filogenetik_uc_renkleri.png'),
               width=3300,height=3150,res=300,bg='white')
tryCatch(make_tree(),finally=grDevices::dev.off())
cat('Üretildi: Fig2_filogenetik_uc_renkleri (PDF ve PNG)\n')

# FIGURE 3 — 8 focal species: 9 dietary categories, scores are semi-quantitative.
focal <- c('Circaetus gallicus','Sagittarius serpentarius','Pandion haliaetus',
           'Gypaetus barbatus','Pernis apivorus','Rostrhamus sociabilis',
           'Gypohierax angolensis','Buteo buteo')
allNames <- gsub('_',' ',z_all$Species3,fixed=TRUE)
idx <- match(focal,allNames)
if (anyNA(idx)) warning('Seçilmiş odak türlerden bazıları tam veri setinde yok.')
focal <- focal[!is.na(idx)]; idx <- idx[!is.na(idx)]
if (length(focal)<4) stop('Heatmap icin yeterli odak tur yok.')
mat <- as.matrix(z_all[idx,col9,drop=FALSE]); storage.mode(mat) <- 'double'
heat <- data.frame(species=rep(focal,times=length(col9)),
                   group=rep(col9,each=length(focal)),score=as.vector(mat))
heat$species <- factor(heat$species,levels=rev(focal))
heat$group <- factor(heat$group,levels=col9,labels=unname(label9[col9]))
p_heat <- ggplot2::ggplot(heat,ggplot2::aes(x=group,y=species,fill=score))+
  ggplot2::geom_tile(colour='#FFFFFF',linewidth=.5)+
  ggplot2::geom_text(ggplot2::aes(label=ifelse(score>=15,sprintf('%.0f',score),'')),
                     colour='#1F2224',size=2.4)+
  ggplot2::scale_fill_gradient(low='#F4F7F8',high='#1D6780',limits=c(0,100),name='Skor (%)')+
  ggplot2::labs(x=NULL,y=NULL)+pub_theme(10)+
  ggplot2::theme(axis.text.x=ggplot2::element_text(angle=45,hjust=1),
                 axis.ticks=ggplot2::element_blank(),axis.line=ggplot2::element_blank(),
                 axis.text.y=ggplot2::element_text(face='italic'))
save_pub(p_heat,'Fig3_odak_turler_diyet_heatmap',9.5,4.6)

# FIGURE 4 — observed genus richness and within-genus distance, descriptive only.
if (any(!is.finite(genus$mean_hellinger_32))) stop('Cins tablosunda geçersiz uzaklık.')
p_genus <- ggplot2::ggplot(genus,
    ggplot2::aes(x=species_richness,y=mean_hellinger_32)) +
  ggplot2::geom_point(colour='#245D72',size=2.8,alpha=.85)+
  ggplot2::scale_x_continuous(breaks=sort(unique(genus$species_richness)))+
  ggplot2::scale_y_continuous(limits=c(0,1))+
  ggplot2::labs(x='Filogenetik eşleşmiş tür sayısı / cins',
                y='Ortalama cins içi Hellinger uzaklığı (32 niş)',
                caption=paste0(nrow(genus),' cins; keşifsel analiz; regresyon çizgisi eklenmedi')) +
  pub_theme(11)+ggplot2::theme(plot.caption=ggplot2::element_text(size=8,hjust=0))
save_pub(p_genus,'Fig4_cins_zenginligi_disparite',6.9,4.7)

# SUPPLEMENT S1 — full starting sample, not restricted to 218 matched tips.
allCode <- as.character(z_all$dominant_diet_code)
if (!all(allCode %in% col9)) stop('251 türde beklenmeyen besin kodu var.')
tb <- table(factor(allCode,levels=col9))
bar <- data.frame(code=names(tb),n=as.integer(tb))
bar <- bar[bar$n>0,,drop=FALSE]
bar$category <- unname(label9[bar$code]); bar$pct <- 100*bar$n/nrow(z_all)
bar$category <- factor(bar$category,levels=rev(bar$category[order(bar$n,decreasing=TRUE)]))
p_bar <- ggplot2::ggplot(bar,ggplot2::aes(x=n,y=category,fill=code))+
  ggplot2::geom_col(width=.7,show.legend=FALSE)+
  ggplot2::geom_text(ggplot2::aes(label=sprintf('%d (%.1f%%)',n,pct)),
                     hjust=-.08,size=3.2)+
  ggplot2::scale_fill_manual(values=colour9)+
  ggplot2::scale_x_continuous(expand=ggplot2::expansion(mult=c(0,.19)))+
  ggplot2::labs(x='Tür sayısı',y=NULL,caption=paste0('n = ',nrow(z_all),' tür; betimsel dağılım'))+
  pub_theme(11)+ggplot2::theme(plot.caption=ggplot2::element_text(size=8,hjust=0))
save_pub(p_bar,'SuppS1_baskin_besin',7.2,4.6)

# SUPPLEMENT S2 — threshold sensitivity from already created 05 table.
allSens <- sens[sens$grup=='Tum turler',,drop=FALSE]
if (!nrow(allSens)) stop('05 eşik duyarlılığında Tum turler satırları bulunamadı.')
curve <- rbind(data.frame(t=allSens$esik,pct=allSens$besin_pct,
                          resolution='9 besin kategorisi'),
               data.frame(t=allSens$esik,pct=allSens$nis_pct,
                          resolution='32 bileşik niş'))
p_sens <- ggplot2::ggplot(curve,
                         ggplot2::aes(x=t,y=pct,colour=resolution,linetype=resolution))+
  ggplot2::geom_line(linewidth=.8)+ggplot2::geom_point(size=2)+
  ggplot2::scale_colour_manual(values=c('9 besin kategorisi'='#0072B2',
                                        '32 bileşik niş'='#BA6E39'))+
  ggplot2::scale_x_continuous(breaks=sort(unique(curve$t)))+
  ggplot2::scale_y_continuous(limits=c(0,100),breaks=seq(0,100,20))+
  ggplot2::labs(x='En yüksek kategori skoru için eşik (%)',
                y='Eşiği karşılayan türler (%)',colour=NULL,linetype=NULL)+
  pub_theme(11)+ggplot2::theme(legend.position='bottom')
save_pub(p_sens,'SuppS2_esik_duyarliligi',7.2,4.7)

writeLines(c(
  'OLUSTURULAN FIGURLER',
  sprintf('Eslestirilen tur: %d; benzersiz tur cifti: %d',N,nrow(pairs)),
  sprintf('Baslangic tur sayisi: %d',nrow(z_all)),
  'Fig1A ve Fig1B: ayni filogenetik x ekseni, ayni 0-1 ekolojik y ekseni',
  'Fig2: fan filogenetik agac; uc isimleri 218 tip yogunlugu nedeniyle kapali',
  sprintf('Fig3: secilmis %d odak tur',length(focal)),
  sprintf('Fig4: %d cok turlu cins',nrow(genus)),
  'S3 tanglegram BU BETIKTE URETILMEDI: 10 nolu gorselde isim-baglanti denetimi gerekli.',
  'NOT: R betiginin yalnizca kaynak kodu ChatGPT tarafindan hazirlandi; kullanicinin Mac ortaminda ilk kez calistirilip dogrulanmali.'
),file.path(out,'11_figures_run_notes.txt'))
cat('\nBİTTİ: ',out,'\n',sep='')
