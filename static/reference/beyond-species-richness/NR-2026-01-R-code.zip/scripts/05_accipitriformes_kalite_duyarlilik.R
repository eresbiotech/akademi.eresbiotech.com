# 05 - Accipitriformes | data-quality and threshold-sensitivity audit
# Inputs: data/processed/accipitriformes_avonet_avoniche_joined.csv
# AVONICHE: Sayol et al. (2026); AVONET: Tobias et al. (2022)
# Taxonomy: BirdTree. This is a descriptive audit, NOT a phylogenetic test.

if (!file.exists('accipitriformes-phylogeny-niche.Rproj')) {
  stop('RStudio proje kokunu acin (accipitriformes-phylogeny-niche.Rproj).')
}
if (!requireNamespace('readr', quietly = TRUE)) {
  stop('readr eksik. install.packages("readr") ile kurun.')
}

input_file <- 'data/processed/accipitriformes_avonet_avoniche_joined.csv'
if (!file.exists(input_file)) stop('04 numarali betigi once calistirin.')
d <- readr::read_csv(input_file, show_col_types = FALSE)

diet_map <- list(
  Pa = c('PAG', 'PAS', 'PAD'),
  Pt = c('PEL', 'PGR'),
  Ne = c('NAE', 'NGL'),
  Se = c('SEL', 'SGR'),
  Fr = c('FAE', 'FGL', 'FGR'),
  In = c('IAE', 'ISA', 'ISS', 'ISG', 'IVS', 'IGE', 'IGG'),
  Ap = c('APA', 'APL', 'APP', 'APG', 'APS', 'APD'),
  Vt = c('VAE', 'VAS', 'VPE', 'VGE', 'VGG'),
  Ca = c('CAQ', 'CGR')
)
diet_cols <- names(diet_map)
forage_cols <- unlist(diet_map, use.names = FALSE)
needed <- c('Species3', 'Inferred', 'dominant_diet_pct',
            'dominant_foraging_pct', diet_cols, forage_cols)
missing <- setdiff(needed, names(d))
if (length(missing)) stop('Eksik sutunlar: ', paste(missing, collapse = ', '))
if (anyDuplicated(d$Species3)) stop('Birden fazla tekrar eden Species3 kaydi var.')
if (anyNA(d[c(diet_cols, forage_cols)])) stop('Nis skorlarinda NA var.')

numeric_cols <- c(diet_cols, forage_cols, 'dominant_diet_pct', 'dominant_foraging_pct')
if (!all(vapply(d[numeric_cols], is.numeric, logical(1)))) {
  stop('Beklenen nis skorlarindan biri numeric degil.')
}

dir.create('outputs/tables', recursive = TRUE, showWarnings = FALSE)
dir.create('outputs/figures', recursive = TRUE, showWarnings = FALSE)

# 1. Category consistency: each 32-niche group should sum to its broad diet score.
# Mapping is based on the ACTUAL BirdTree file column codes (e.g., VPE and CGR),
# which may differ from code labels printed in some versions of the manuscript.
consistency <- do.call(rbind, lapply(names(diet_map), function(k) {
  dif <- as.numeric(d[[k]]) - rowSums(as.matrix(d[diet_map[[k]]]))
  data.frame(diet_code = k,
             n_checked = nrow(d),
             max_abs_difference = max(abs(dif)),
             n_over_1pct = sum(abs(dif) > 1),
             stringsAsFactors = FALSE)
}))
readr::write_csv(consistency, 'outputs/tables/05_kategori_tutarliligi.csv')
if (any(consistency$n_over_1pct > 0)) {
  warning('9 ana kategori ile 32 alt kategori arasinda >1 puan fark bulundu. ' ,
          'outputs/tables/05_kategori_tutarliligi.csv dosyasini inceleyin.')
}

# 2. Inferred flag values from AVONICHE documentation:
# 0 = directly scored, 1 = partially/fully inferred from a close relative,
# 2 = inferred after taxonomy split/lump. Do NOT silently treat blank as 0.
d$inferred_flag <- trimws(as.character(d$Inferred))
d$inferred_flag[is.na(d$Inferred) | d$inferred_flag == ''] <- 'Missing'
labels <- c('0' = 'Literaturden dogrudan', '1' = 'Yakin akrabadan tahmin',
            '2' = 'Taksonomik bolunme/birlesme', 'Missing' = 'Eksik')
d$inferred_label <- ifelse(d$inferred_flag %in% names(labels),
                           unname(labels[d$inferred_flag]),
                           paste0('Diger: ', d$inferred_flag))
flags <- as.data.frame(table(d$inferred_label), stringsAsFactors = FALSE)
names(flags) <- c('kayit_turu', 'tur_sayisi')
flags$oran_yuzde <- round(100 * flags$tur_sayisi / nrow(d), 2)
readr::write_csv(flags, 'outputs/tables/05_inferred_dagilimi.csv')

# 3. Threshold sensitivity: categorical dominance at 50, 60, 70, 80, 90, 100.
# This is NOT an absolute measure of ecological specialisation.
thresholds <- c(50, 60, 70, 80, 90, 100)
calculate_threshold <- function(dat, group_name) {
  do.call(rbind, lapply(thresholds, function(t) {
    n_diet <- sum(dat$dominant_diet_pct >= t)
    n_forage <- sum(dat$dominant_foraging_pct >= t)
    data.frame(grup = group_name, esik = t, tur_sayisi = nrow(dat),
               besin_n = n_diet, besin_pct = round(100 * n_diet/nrow(dat), 2),
               nis_n = n_forage, nis_pct = round(100 * n_forage/nrow(dat), 2),
               fark_yuzde_puan = round(100*(n_diet-n_forage)/nrow(dat), 2))
  }))
}
if (nrow(d) < 1) stop('Analiz icin kayit yok.')
sensitivity <- calculate_threshold(d, 'Tum turler')
direct <- d[d$inferred_flag == '0', , drop = FALSE]
if (nrow(direct) > 0) {
  sensitivity <- rbind(sensitivity, calculate_threshold(direct, 'Yalniz dogrudan puanlanmis'))
}
readr::write_csv(sensitivity, 'outputs/tables/05_esik_duyarliligi.csv')

# 4. Focus species provenance, dominance, and Shannon-effective-category outputs.
focus <- c('Sagittarius serpentarius', 'Pandion haliaetus',
           'Circaetus gallicus', 'Pernis apivorus', 'Gypaetus barbatus',
           'Rostrhamus sociabilis', 'Gypohierax angolensis', 'Buteo buteo')
focus_cols <- intersect(c('Species3', 'Family3', 'Inferred', 'inferred_label',
                          'dominant_diet_code', 'dominant_diet_pct',
                          'dominant_foraging_code', 'dominant_foraging_pct',
                          'diet_effective_categories', 'foraging_effective_categories'), names(d))
focus_result <- d[d$Species3 %in% focus, focus_cols, drop = FALSE]
readr::write_csv(focus_result, 'outputs/tables/05_odak_turler_veri_kaynagi.csv')

# 5. Simple plot - thresholds (no phylogeny/ancestral reconstruction).
if (requireNamespace('ggplot2', quietly = TRUE)) {
  a <- sensitivity[sensitivity$grup == 'Tum turler', , drop = FALSE]
  plot_data <- rbind(
    data.frame(esik = a$esik, oran = a$besin_pct, tur = '9 besin kategorisi'),
    data.frame(esik = a$esik, oran = a$nis_pct, tur = '32 beslenme/avlanma nisi')
  )
  fig <- ggplot2::ggplot(plot_data, ggplot2::aes(x = esik, y = oran, linetype = tur)) +
    ggplot2::geom_line(linewidth = 0.9) +
    ggplot2::geom_point(size = 2.4) +
    ggplot2::scale_x_continuous(breaks = thresholds) +
    ggplot2::scale_y_continuous(limits = c(0, 100)) +
    ggplot2::labs(title = 'Accipitriformes: baskin kategori esigine duyarlilik',
                  subtitle = paste0(nrow(d), ' BirdTree turu | ekolojik skorlar; filogenetik test degil'),
                  x = 'Baskin kategori esigi (%)', y = 'Esigi karsilayan turler (%)',
                  linetype = 'Siniflama duzeyi') +
    ggplot2::theme_minimal(base_size = 12)
  ggplot2::ggsave('outputs/figures/05_esik_duyarliligi.png', fig,
                  width = 10, height = 6, dpi = 300)
}

cat('\nKALITE + ESİK DUYARLILIGI TAMAMLANDI\n')
cat('Tur sayisi: ', nrow(d), '\n', sep = '')
cat('\nKATEGORI TUTARLILIGI:\n'); print(consistency, row.names = FALSE)
cat('\nINFERRED DAGILIMI:\n'); print(flags, row.names = FALSE)
cat('\nESIK DUYARLILIGI:\n'); print(sensitivity, row.names = FALSE)
cat('\nODAK TURLER:\n'); print(focus_result)
cat('\nKayitlar: outputs/tables/05_*.csv ve outputs/figures/05_esik_duyarliligi.png\n')
cat('UYARI: Skorlar literatur betimlemelerinden uretilmis yari-nicel tahminlerdir.\n')
cat('UYARI: 9 ve 32 kategorinin oranlari hiyerarsik olceklere aittir; farkin bir\n')
cat('       kismi daha ince siniflama yapisindan beklenir. Bu filogenetik kanit degildir.\n')
