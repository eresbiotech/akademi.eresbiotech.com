# 09 | Accipitriformes: molecular tree vs ecological niche structure
# Fast exploratory analysis. Requires successful 04 and 06 scripts.
# One primary analysis (32 AVONICHE foraging-diet niches), one sensitivity
# analysis (9 parent diet categories), one species-label permutation null.
# Adds a brief genus richness vs niche disparity exploratory comparison.
# Does NOT infer extinction, adaptive radiation timing, or causal biogeography.

if (!requireNamespace('ape', quietly = TRUE)) stop('Eksik R paketi: install.packages("ape")')
input <- 'data/processed/accipitriformes_avonet_avoniche_joined.csv'
phyfile <- 'data/processed/06_phylogeny.rds'
mapfile <- 'data/processed/06_phylo_matched_traits.csv'
for (f in c(input, phyfile, mapfile)) {
  if (!file.exists(f)) stop('Eksik dosya: ', f, '\nOnce 04 ve 06 betiklerini calistirin.')
}
for (d in c('outputs/tables', 'outputs/figures'))
  dir.create(d, recursive=TRUE, showWarnings=FALSE)

z <- utils::read.csv(input, check.names=FALSE, stringsAsFactors=FALSE)
m <- utils::read.csv(mapfile, check.names=FALSE, stringsAsFactors=FALSE)
phy <- readRDS(phyfile)
stopifnot(inherits(phy, 'phylo'))
need <- c('Species3','tree_tip')
if (!all(need %in% names(m))) stop('06 eslesme dosyasinda gerekli sutunlar yok.')
if (anyDuplicated(m$tree_tip) || anyDuplicated(z$Species3)) stop('Tekrarlanan takson adi bulundu.')
map_ids <- match(phy$tip.label, m$tree_tip)
if (anyNA(map_ids)) stop('06 agac uc adlari ile eslesme tablosu tutarsiz.')
sp_keys <- m$Species3[map_ids]
zi <- match(sp_keys, z$Species3)
if (anyNA(zi)) stop('06 eslesme tablosunda 04 verisinde bulunmayan tur var.')
z <- z[zi, , drop=FALSE]
species <- gsub('_',' ',as.character(z$Species3),fixed=TRUE)
if (anyDuplicated(species)) stop('Tur adlarinda cakisma var.')
if (length(species) != length(phy$tip.label)) stop('Filogeni ve veri boyutlari uyusmuyor.')

cols9 <- c('Pa','Pt','Ne','Se','Fr','In','Ap','Vt','Ca')
cols32 <- c('PAG','PAS','PAD','PEL','PGR','NAE','NGL','SEL','SGR',
            'FAE','FGL','FGR','IAE','ISA','ISS','ISG','IVS','IGE','IGG',
            'APA','APL','APP','APG','APS','APD','VAE','VAS','VPE','VGE','VGG',
            'CAQ','CGR')
if (!all(c(cols9,cols32) %in% names(z))) stop('AVONICHE 9 veya 32 kategori sutunlari yok.')
hellinger <- function(cols) {
  a <- as.matrix(z[,cols,drop=FALSE]); storage.mode(a) <- 'double'
  if (any(!is.finite(a)) || any(a<0) || any(abs(rowSums(a)-100)>1))
    stop('Gecersiz AVONICHE yuzde/skor degeri: ',paste(cols[1:2],collapse=', '))
  a <- sqrt(a/rowSums(a))
  out <- as.matrix(stats::dist(a))/sqrt(2)
  dimnames(out) <- list(species,species)
  out
}
D32 <- hellinger(cols32)
D9 <- hellinger(cols9)
PDist <- ape::cophenetic.phylo(phy)
PDist <- PDist[phy$tip.label, phy$tip.label, drop=FALSE]
# Matrix sequence matches z because z is aligned to the exact tree tip order.
if (!identical(phy$tip.label, m$tree_tip[map_ids])) stop('Unexpected tree order.')
if (any(!is.finite(PDist)) || !all(dim(PDist)==dim(D32))) stop('Gecersiz filogenetik uzaklik.')
N <- length(species)
u <- upper.tri(D32)

# Spearman correlation of phylogenetic and ecological pairwise distances.
# Rank each matrix once. Permuting species labels keeps the observed
# distance distribution, and avoids treating species pairs as independent.
rank_distance <- function(d) {
  a <- matrix(0, nrow(d), ncol(d))
  a[u] <- rank(d[u], ties.method='average')
  a + t(a)
}
phyrank <- rank(PDist[u],ties.method='average')
R32 <- rank_distance(D32); R9 <- rank_distance(D9)
obs32 <- stats::cor(phyrank,R32[u])
obs9 <- stats::cor(phyrank,R9[u])
B <- as.integer(Sys.getenv('RAPTOR_PERM', '499'))
if (is.na(B) || B < 99) stop('RAPTOR_PERM en az 99 olmali.')
set.seed(20261119)
null32 <- numeric(B); null9 <- numeric(B)
for (b in seq_len(B)) {
  p <- sample.int(N)
  null32[b] <- stats::cor(phyrank,R32[p,p][u])
  null9[b] <- stats::cor(phyrank,R9[p,p][u])
}
perm_p <- function(obs,v) (1+sum(abs(v)>=abs(obs)))/(1+length(v))
res <- data.frame(
  measure=c('32_nis_besin_avlanma','9_besin'),
  n_species=N, n_pairs=sum(u),
  mantel_like_spearman=c(obs32,obs9),
  permutation_p=c(perm_p(obs32,null32),perm_p(obs9,null9)),
  permutations=B,
  interpretation='Phylogenetic distance vs ecological Hellinger distance; species-label permutation'
)
utils::write.csv(res,'outputs/tables/09_iki_agac_istatistik.csv',row.names=FALSE)

# Genus richness vs ecological disparity is a second, purely exploratory view.
groups <- split(seq_len(N),sub(' .*$', '',species))
groups <- groups[lengths(groups)>=2]
within_mean <- function(ii, d) mean(d[ii,ii,drop=FALSE][upper.tri(d[ii,ii,drop=FALSE])])
if (length(groups)>=4 && length(unique(lengths(groups)))>1) {
  ns <- lengths(groups)
  disparity <- vapply(groups,within_mean,numeric(1),d=D32)
  rho <- suppressWarnings(stats::cor(as.numeric(ns), disparity,method='spearman'))
  nullrho <- numeric(B)
  for (b in seq_len(B)) {
    p <- sample.int(N)
    dp <- D32[p,p]
    dif <- vapply(groups,within_mean,numeric(1),d=dp)
    nullrho[b] <- suppressWarnings(stats::cor(as.numeric(ns),dif,method='spearman'))
  }
  genus_res <- data.frame(genus=names(groups),species_richness=as.integer(ns),
                          mean_hellinger_32=unname(disparity))
  utils::write.csv(genus_res,'outputs/tables/09_cins_zenginligi_nis_farkliligi.csv',row.names=FALSE)
  genus_line <- sprintf('Cins ici (kesifsel): %d cins | Spearman rho=%.3f | etiket-rastgelelestirme p=%.3f',
                        length(groups),rho,perm_p(rho,nullrho))
} else genus_line <- 'Cins analizi: yeterli sayida cok turlu cins/degiskenlik yok.'

# Tanglegram of a priori selected focal species, if available.
focal <- c('Sagittarius serpentarius','Pandion haliaetus','Circaetus gallicus',
           'Gypaetus barbatus','Buteo buteo','Pernis apivorus',
           'Rostrhamus sociabilis','Gypohierax angolensis')
selected <- intersect(focal,species)
plot_note <- 'Tanglegram olusmadi: yeterli odak tur veya phytools paketi yok.'
if (length(selected)>=5 && requireNamespace('phytools',quietly=TRUE)) {
  tips <- phy$tip.label[species %in% selected]
  pp <- ape::drop.tip(phy,setdiff(phy$tip.label,tips))
  # Match the tip labels to visible species names, not taxon-code aliases.
  pp$tip.label <- species[match(pp$tip.label,phy$tip.label)]
  ee <- ape::as.phylo(stats::hclust(as.dist(D32[selected,selected,drop=FALSE]),method='average'))
  cp <- phytools::cophylo(pp,ee,rotate=TRUE)
  grDevices::png('outputs/figures/09_molekuler_ekolojik_tanglegram.png',width=2800,height=1700,res=250)
  par(mar=c(2,2,3,2))
  plot(cp,fsize=.67,link.type='curved',link.lwd=.8)
  title(main='Molekuler filogeni (sol) / ekolojik benzerlik (sag) — secili turler')
  grDevices::dev.off()
  plot_note <- paste('Tanglegram:',length(selected),'onceden belirlenmis temsilci tur.')
}

report <- c(
  'ACCIPITRIFORMES — 09 / 30 DAKIKALIK PILOT',
  sprintf('Filogenide eslesen tur sayisi: %d',N),
  sprintf('32 bilesik nis: rho=%.3f | permutasyon p=%.3f',obs32,perm_p(obs32,null32)),
  sprintf('9 besin grubu (duyarlilik): rho=%.3f | permutasyon p=%.3f',obs9,perm_p(obs9,null9)),
  sprintf('Rastgelelestirme: %d kez tur etiketleri karistirildi.',B),
  genus_line,plot_note,
  'YORUM: Pozitif rho filogenetik uzaklik arttikca ekolojik farkliligin arttigina isaret eder.',
  'Kucuk/anlamsiz rho bu veri ve olcekte bir iliski bulunamadigi anlamina gelir; bagimsizlik ispatlanmaz.',
  'SINIR: Yok olus, radiation zamani, bos nislerin doldurulmasi ve biyocografik nedensellik TEST EDILMEDI.',
  'SINIR: Ekolojik agac zamansal filogeni degildir; yarı nicel AVONICHE olcumleridir.',
  'SINIR: McTavish yayimlanmis filogenetik sentez agacinda molekuler veri olmadan eklenen taksonlar olabilir.',
  'SONRAKI IS: Tek sonuc tablosu ve tek tanglegram ile makalenin Bulgular kismini yaz.'
)
writeLines(report,'outputs/09_30dk_sonuc.txt',useBytes=TRUE)
cat(paste(report,collapse='\n'),'\n')
