# Accipitriformes ecology project — AVONET data recovery
# Source: Tobias et al. (2022), Figshare DOI:10.6084/m9.figshare.16586228
# Read the XLSX workbook, NOT a CSV. No phylogenetic tree is fabricated here.

pkgs <- c("readxl", "readr", "dplyr")
missing_pkgs <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_pkgs)) install.packages(missing_pkgs)

# Run from the root of accipitriformes-phylogeny-niche.Rproj
if (!file.exists("accipitriformes-phylogeny-niche.Rproj")) {
  stop("RStudio projenizi acin: accipitriformes-phylogeny-niche.Rproj. Sonra yeniden deneyin.")
}
dir.create("data/raw", recursive = TRUE, showWarnings = FALSE)
dir.create("data/processed", recursive = TRUE, showWarnings = FALSE)

file <- "data/raw/AVONET_Supplementary_dataset_1.xlsx"
url <- "https://ndownloader.figshare.com/files/34480856"

# Existing file is reused. To force a fresh download, delete the local file.
if (!file.exists(file) || is.na(file.info(file)$size) || file.info(file)$size < 100000L) {
  message("AVONET Excel dosyasi indiriliyor...")
  result <- tryCatch(
    utils::download.file(url, destfile = file, mode = "wb", method = "libcurl", quiet = FALSE),
    error = function(e) e
  )
  if (inherits(result, "error") || !file.exists(file) || file.info(file)$size < 100000L) {
    stop(paste0(
      "AVONET indirilemedi. Tarayicida su baglantiyi acip ",
      "Excel dosyasini data/raw/AVONET_Supplementary_dataset_1.xlsx adiyla kaydedin: ",
      url, ". Ardindan betigi tekrar calistirin."
    ))
  }
}

sheets <- tryCatch(readxl::excel_sheets(file), error = function(e) {
  stop("Dosya gecersiz bir Excel dosyasi olabilir: ", conditionMessage(e))
})
print(sheets)
sheet <- "AVONET3_BirdTree"
if (!sheet %in% sheets) stop("Beklenen sayfa bulunamadi: ", sheet)

raw <- readxl::read_excel(file, sheet = sheet)
message("Okunan satir sayisi: ", nrow(raw))
message("Kolonlar: ", paste(names(raw), collapse = ", "))
required <- c("Species3", "Order3", "Family3")
if (!all(required %in% names(raw))) {
  stop("Taksonomi kolonlari beklenenden farkli. Kolon adlarini kontrol edin.")
}

raptors <- raw[trimws(as.character(raw$Order3)) == "Accipitriformes", , drop = FALSE]
if (nrow(raptors) == 0L) stop("Order3 icinde Accipitriformes bulunamadi; veri sayfasini kontrol edin.")
want <- c("Species3", "Family3", "Order3", "Trophic.Niche", "Primary.Lifestyle", "Realm", "Mass")
raptors <- raptors[, intersect(want, names(raptors)), drop = FALSE]
readr::write_csv(raptors, "data/processed/avonet_accipitriformes_birdtree.csv")

message("Basarili: ", nrow(raptors), " AVONET BirdTree taksonomisine ait Accipitriformes satiri.")
message("Kaydedildi: data/processed/avonet_accipitriformes_birdtree.csv")
message("NOT: Bu sayi AviList 2025'teki 252 tur ile birebir ayni olmak zorunda degildir.")
message("NOT: Trophic.Niche, yilan/balik/ari gibi her av turunu tek tek kodlamaz.")
