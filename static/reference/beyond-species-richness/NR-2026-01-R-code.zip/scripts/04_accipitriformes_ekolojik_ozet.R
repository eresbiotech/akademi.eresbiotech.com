# Accipitriformes ecology: AVONET + AVONICHE descriptive overview
# Sources: Tobias et al. (2022) AVONET; Sayol et al. (2026) AVONICHE
# TAXONOMY: BirdTree 2012 (both datasets), not AviList 2025
# NOTE: this is NOT a phylogenetic analysis / ancestral-state reconstruction.

required_packages <- c("readr", "dplyr", "tidyr", "ggplot2")
missing_packages <- required_packages[!vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_packages)) {
  stop("Eksik R paketleri: ", paste(missing_packages, collapse = ", "),
       ". Once install.packages(c(", paste(sprintf('"%s"', missing_packages), collapse = ", "), ")) calistirin.")
}

root_project <- "accipitriformes-phylogeny-niche.Rproj"
if (!file.exists(root_project)) stop("RStudio'da projenizin kok klasorunu acin: ", root_project)
input_a <- "data/processed/avonet_accipitriformes_birdtree.csv"
input_b <- "data/processed/avoniche_accipitriformes_birdtree.csv"
if (!file.exists(input_a) || !file.exists(input_b)) stop("Once 02 ve 03 betiklerini calistirin; iki islenmis CSV gerekli.")

dir.create("outputs/tables", recursive = TRUE, showWarnings = FALSE)
dir.create("outputs/figures", recursive = TRUE, showWarnings = FALSE)

a <- readr::read_csv(input_a, show_col_types = FALSE)
b <- readr::read_csv(input_b, show_col_types = FALSE)
if (!"Species3" %in% names(a) || !"Species3" %in% names(b)) stop("Species3 adi her iki tabloda da olmali.")
if (anyNA(a$Species3) || anyNA(b$Species3)) stop("Bos tur adi bulundu.")
if (anyDuplicated(a$Species3) || anyDuplicated(b$Species3)) stop("Tekrarlanan Species3 adi var; join oncesi kontrol gerekli.")
if (nrow(a) != 251 || nrow(b) != 251) {
  warning("Beklenen 251 satir degisti: AVONET=", nrow(a), " AVONICHE=", nrow(b), ".")
}
if (!setequal(a$Species3, b$Species3)) stop("Tur listeleri birebir eslesmiyor; join durduruldu.")

# Same taxonomy: add niche information while keeping AVONET morphology and traits.
b_eco <- dplyr::select(b, -dplyr::any_of(c("Family3", "Order3")))
dat <- dplyr::inner_join(a, b_eco, by = "Species3")
stopifnot(nrow(dat) == nrow(a))

# 9 diet categories and 32 composite foraging niches defined by AVONICHE.
diet_names <- c(
  Pa = "Sucul bitkiler", Pt = "Karasal bitkiler", Ne = "Nektar",
  Se = "Tohum", Fr = "Meyve", In = "Omurgasizlar",
  Ap = "Sucul av (balik + omurgasiz)", Vt = "Omurgalilar", Ca = "Les"
)
diet_cols <- names(diet_names)
forage_cols <- c(
  "PAG","PAS","PAD", "PEL","PGR", "NAE","NGL", "SEL","SGR",
  "FAE","FGL","FGR", "IAE","ISA","ISS","ISG","IVS","IGE","IGG",
  "APA","APL","APP","APG","APS","APD", "VAE","VAS","VPE","VGE","VGG",
  "CAQ","CGR"
)
if (length(forage_cols) != 32) stop("32 niş kodunun sayisi yanlis.")
missing_cols <- setdiff(c(diet_cols, forage_cols), names(dat))
if (length(missing_cols)) stop("Eksik AVONICHE sutunlari: ", paste(missing_cols, collapse = ", "))
if (!all(vapply(dat[c(diet_cols, forage_cols)], is.numeric, logical(1)))) {
  stop("Bazi niş skor sutunlari sayisal degil; ham CSV ve decimal ayiricisini kontrol edin.")
}
if (anyNA(dat[c(diet_cols, forage_cols)])) stop("Niş skorlarinda NA var; eksik veri stratejisi belirlenmeli.")

# AVONICHE scores are in percent, and categories sum to ~100 for every species.
mat9 <- as.matrix(dat[diet_cols]); mat32 <- as.matrix(dat[forage_cols])
if (any(mat9 < 0 | mat9 > 100) || any(mat32 < 0 | mat32 > 100)) {
  stop("0-100 disinda niş skoru var; olcek dogrulanmali.")
}
sum9 <- rowSums(mat9); sum32 <- rowSums(mat32)
message("9 kategori toplam araligi: ", round(min(sum9), 3), " - ", round(max(sum9), 3))
message("32 kategori toplam araligi: ", round(min(sum32), 3), " - ", round(max(sum32), 3))
if (any(abs(sum9 - 100) > 1) || any(abs(sum32 - 100) > 1)) {
  stop("Niş skorlarinin toplami 100'e yakin degil; normalization yapmadan once inceleyin.")
}

# Dominant category, percentage and effective number of resource categories (exp Shannon).
# This is a DESCRIPTIVE diversity index, not the actual number of prey species.
shannon_effective <- function(m) {
  x <- m / rowSums(m)
  exp(-rowSums(ifelse(x > 0, x * log(pmax(x, .Machine$double.eps)), 0)))
}

winner9 <- diet_cols[max.col(mat9, ties.method = "first")]
winner32 <- forage_cols[max.col(mat32, ties.method = "first")]
dat$dominant_diet_code <- winner9
dat$dominant_diet_tr <- unname(diet_names[winner9])
dat$dominant_diet_pct <- apply(mat9, 1, max)
dat$diet_specialist_60 <- dat$dominant_diet_pct >= 60
dat$diet_effective_categories <- shannon_effective(mat9)
dat$dominant_foraging_code <- winner32
dat$dominant_foraging_pct <- apply(mat32, 1, max)
dat$foraging_specialist_60 <- dat$dominant_foraging_pct >= 60
dat$foraging_effective_categories <- shannon_effective(mat32)

readr::write_csv(dat, "data/processed/accipitriformes_avonet_avoniche_joined.csv")

# Simple summaries, deliberately NOT interpreted as evolutionary transitions.
summary_diet <- dat |>
  dplyr::count(dominant_diet_code, dominant_diet_tr, name = "tur_sayisi", sort = TRUE)
summary_forage <- dat |>
  dplyr::count(dominant_foraging_code, name = "tur_sayisi", sort = TRUE)
readr::write_csv(summary_diet, "outputs/tables/baskin_besin_gruplari.csv")
readr::write_csv(summary_forage, "outputs/tables/baskin_avlanma_nisleri.csv")

# Focal taxa: show measured/estimated category scores without suggesting exact prey.
focal <- c("Sagittarius serpentarius", "Pandion haliaetus", "Circaetus gallicus",
           "Pernis apivorus", "Gypaetus barbatus", "Rostrhamus sociabilis",
           "Gypohierax angolensis", "Buteo buteo")
display_species <- gsub("_", " ", as.character(dat$Species3))
shown <- dat[display_species %in% focal, , drop = FALSE]
not_found <- setdiff(focal, display_species)
if (length(not_found)) message("Bu taksonomide eslesmeyen odak turler: ", paste(not_found, collapse = ", "))

detail_cols <- intersect(c("Species3", "Family3", "Inferred", "dominant_diet_code",
                           "dominant_diet_pct", "diet_specialist_60", "dominant_foraging_code",
                           "dominant_foraging_pct", "foraging_specialist_60", "diet_effective_categories",
                           "foraging_effective_categories", diet_cols, forage_cols), names(shown))
readr::write_csv(shown[detail_cols], "outputs/tables/odak_turler_detay.csv")

p1 <- ggplot2::ggplot(summary_diet,
                      ggplot2::aes(x = stats::reorder(dominant_diet_tr, tur_sayisi), y = tur_sayisi)) +
  ggplot2::geom_col() + ggplot2::coord_flip() +
  ggplot2::labs(title = "Accipitriformes: baskin besin grubu (BirdTree)",
                subtitle = paste0("Tur sayisi: ", nrow(dat), " | AVONICHE ana diet kategorileri"),
                x = "Baskin kategori", y = "Tur sayisi") +
  ggplot2::theme_minimal(base_size = 12)
ggplot2::ggsave("outputs/figures/01_baskin_besin_gruplari.png", p1,
                width = 10, height = 6, dpi = 300)

if (nrow(shown)) {
  pdat <- shown |>
    dplyr::select(Species3, dplyr::all_of(diet_cols)) |>
    tidyr::pivot_longer(cols = dplyr::all_of(diet_cols),
                        names_to = "diet_code", values_to = "oran") |>
    dplyr::mutate(diet = factor(unname(diet_names[diet_code]), levels = unname(diet_names)))
  p2 <- ggplot2::ggplot(pdat,
                         ggplot2::aes(x = Species3, y = oran, fill = diet)) +
    ggplot2::geom_col() + ggplot2::coord_flip() +
    ggplot2::scale_y_continuous(limits = c(0, 100), expand = ggplot2::expansion(mult = c(0, .02))) +
    ggplot2::labs(title = "Secilmis yirtici kuslarda besin kategorileri",
                  subtitle = "Oransal AVONICHE skorlaridir; av turune ozel saha gozlemi degildir",
                  x = NULL, y = "Skor (%)", fill = "Besin grubu") +
    ggplot2::theme_minimal(base_size = 11)
  ggplot2::ggsave("outputs/figures/02_odak_turler_diyet.png", p2,
                  width = 12, height = 6.5, dpi = 300)
}

cat("\nTAMAMLANDI\n")
cat("Eslesen tur sayisi: ", nrow(dat), "\n", sep = "")
cat("Besin kategorisinde >=%60 baskinlik: ", sum(dat$diet_specialist_60), "/", nrow(dat), "\n", sep = "")
cat("Besin+avlanma nisinde >=%60 baskinlik: ", sum(dat$foraging_specialist_60), "/", nrow(dat), "\n", sep = "")
print(summary_diet)
print(shown[c("Species3", "dominant_diet_code", "dominant_diet_pct",
              "dominant_foraging_code", "dominant_foraging_pct")])
cat("\nKaydedilenler: data/processed/accipitriformes_avonet_avoniche_joined.csv,\n",
    "outputs/tables/ ve outputs/figures/\n", sep = "")
cat("UYARI: Inferred sutununu kontrol edin; farkli kaynaklardan tahmini niş skorları bulunabilir.\n")
cat("UYARI: Ap kategorisi balik + sucul omurgasizlari birlestirir, Vt yilanlari diger omurgalilardan ayirmaz.\n")
cat("UYARI: Bu betik filogenetik agac uretmez veya ata nişini tahmin etmez.\n")
